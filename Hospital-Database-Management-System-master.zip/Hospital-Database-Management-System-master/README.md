# Hospital-Database-Management-System
========================================Read me===========================================
1. Install the XAMPP or WAMP
2.For xamp server Copy the hospital folder in the C:\\xampp/htdocs
3.For wamp server, Copy the hospital folder in the C:\\wamp/www


Installing the DB
1. Run the XAMPP/WAMP application (make sure that the apache and mysql are running)
2.Open Browser (google chrome, mozilla firefox)
3.Type the url localhost/phpmyadmin
4.Create DB with the name hospital 
5.Click the created DB and import the sql (hospital .sql)

Accessing the system
1.Run the XAMPP/WAMP application (make sure that the apache and mysql are running)
2.Open Browser (google chrome, mozilla firefox)
3.type in the url (localhost/hospital )
4.ENJOY!


Admin Login Details
user: admin@gmail.com
pass: admin
If you develop issues, hit me up!
whatsapp 2347039001367
![patient listspng](https://user-images.githubusercontent.com/32623706/46237135-951e0880-c37a-11e8-9768-041cc6cc6d22.png)
![new patient3](https://user-images.githubusercontent.com/32623706/46237136-95b69f00-c37a-11e8-9a41-81042b88bb27.png)
![new patient2](https://user-images.githubusercontent.com/32623706/46237137-95b69f00-c37a-11e8-8b36-3002254854c1.png)
![new patient](https://user-images.githubusercontent.com/32623706/46237138-964f3580-c37a-11e8-83f8-d200993842b1.png)
![ucscreenshot20180919095910](https://user-images.githubusercontent.com/32623706/46237139-964f3580-c37a-11e8-971d-cb452ddfa770.png)
![logon](https://user-images.githubusercontent.com/32623706/46237140-96e7cc00-c37a-11e8-8b89-59af952eebef.png)
![diagnosis](https://user-images.githubusercontent.com/32623706/46237141-96e7cc00-c37a-11e8-849b-5a4e6e60ca78.png)
![appointmentlist](https://user-images.githubusercontent.com/32623706/46237142-97806280-c37a-11e8-9273-d92a42cfb871.png)
![appointmentadd](https://user-images.githubusercontent.com/32623706/46237143-97806280-c37a-11e8-9f10-7fdb55a7f6fa.png)
![doctoradd](https://user-images.githubusercontent.com/32623706/46237145-9818f900-c37a-11e8-9f06-784c26672380.png)
![doctorlist](https://user-images.githubusercontent.com/32623706/46237146-98b18f80-c37a-11e8-87ef-ae1ec9386b79.png)
